
const quizContainer = document.getElementById('quiz');
const resultsContainer = document.getElementById('results');
const submitButton = document.getElementById('submit');

const quizQuestions = [
    {
        question: "Which HTML tag is used to create a hyperlink?",
        answers: {
            a: "<a>",
            b: "<link>",
            c: "<href>"
        },
        correctAnswer: "a"
    },
    {
        question: "Which CSS property controls the text size?",
        answers: {
            a: "font-size",
            b: "text-style",
            c: "text-size"
        },
        correctAnswer: "a"
    },
    {
        question: "Inside which HTML element do we put JavaScript code?",
        answers: {
            a: "<script>",
            b: "<js>",
            c: "<javascript>"
        },
        correctAnswer: "a"
    },
    {
        question: "Which method is used to add an element at the end of an array in JavaScript?",
        answers: {
            a: "push()",
            b: "pop()",
            c: "append()"
        },
        correctAnswer: "a"
    },
    {
        question: "Which company developed JavaScript?",
        answers: {
            a: "Microsoft",
            b: "Netscape",
            c: "Google"
        },
        correctAnswer: "b"
    }
];

function buildQuiz(){
    const output = [];
    quizQuestions.forEach((currentQuestion, questionNumber) => {
        const answers = [];
        for(letter in currentQuestion.answers){
            answers.push(
                `<label>
                    <input type="radio" name="question${questionNumber}" value="${letter}">
                    ${letter} : ${currentQuestion.answers[letter]}
                </label>`
            );
        }
        output.push(
            `<div class="question"> ${currentQuestion.question} </div>
            <div class="answers"> ${answers.join('')} </div>`
        );
    });
    quizContainer.innerHTML = output.join('');
}

function showResults(){
    const answerContainers = quizContainer.querySelectorAll('.answers');
    let numCorrect = 0;

    quizQuestions.forEach((currentQuestion, questionNumber) => {
        const answerContainer = answerContainers[questionNumber];
        const selector = `input[name=question${questionNumber}]:checked`;
        const userAnswer = (answerContainer.querySelector(selector) || {}).value;
        
        if(userAnswer === currentQuestion.correctAnswer){
            numCorrect++;
            answerContainers[questionNumber].style.backgroundColor = '#d4edda';
        } else {
            answerContainers[questionNumber].style.backgroundColor = '#f8d7da';
        }
    });

    resultsContainer.innerHTML = `You scored ${numCorrect} out of ${quizQuestions.length}`;
}

buildQuiz();
submitButton.addEventListener('click', showResults);
