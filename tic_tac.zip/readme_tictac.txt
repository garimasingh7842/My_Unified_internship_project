Tic-Tac-Toe Game

This is my version of the classic **Tic-Tac-Toe** game made using HTML, CSS, and JavaScript.  
It’s a simple two-player game where Player X and Player O take turns until someone wins or the match ends in a tie.  
I built this project to practice my front-end development skills and create something fun and interactive.



✨ What’s Inside
- Clean and simple **3x3 game board**.
- Two-player turn system (X and O).
- Win check for rows, columns, and diagonals.
- Tie detection when the board is full.
- Restart button to play again.
- Works on both desktop and mobile.



🛠 Technologies Used
HTML → Structure of the game.
CSS → Styling and making it responsive.
JavaScript → Game logic and interactivity.




🎮 How to Play
1. Open `index.html` in your browser.
2. Player X starts the first move.
3. Click on any empty cell to place your mark.
4. First to get three in a row (horizontal, vertical, or diagonal) wins.
5. If all cells are filled without a winner, it’s a tie.
6. Use the **Restart Game** button to start a new round.



🚀 Why I Made This
I wanted to challenge myself with JavaScript game logic and DOM manipulation.  
It’s also a fun way to combine HTML, CSS, and JS in one small project.





