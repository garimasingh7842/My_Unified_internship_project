const form = document.getElementById("recipeForm");
const recipeList = document.getElementById("recipeList");
const searchInput = document.getElementById("search");

let recipes = JSON.parse(localStorage.getItem("recipes")) || [];

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const ingredients = document.getElementById("ingredients").value.trim();
  const steps = document.getElementById("steps").value.trim();
  const imageInput = document.getElementById("image");

  if (!name || !ingredients || !steps || !imageInput.files.length) {
    alert("Please fill in all fields.");
    return;
  }

  const reader = new FileReader();
  reader.onload = function () {
    const recipe = {
      name,
      ingredients,
      steps,
      image: reader.result,
    };
    recipes.push(recipe);
    localStorage.setItem("recipes", JSON.stringify(recipes));
    displayRecipes(recipes);
    form.reset();
  };
  reader.readAsDataURL(imageInput.files[0]);
});

function displayRecipes(recipesToDisplay) {
  recipeList.innerHTML = "";
  recipesToDisplay.forEach((recipe) => {
    const div = document.createElement("div");
    div.classList.add("recipe-card");

    div.innerHTML = `
      <img src="${recipe.image}" alt="${recipe.name}" />
      <h2>${recipe.name}</h2>
      <p><strong>Ingredients:</strong> ${recipe.ingredients}</p>
      <p><strong>Steps:</strong> ${recipe.steps}</p>
    `;
    recipeList.appendChild(div);
  });
}

searchInput.addEventListener("input", function () {
  const query = this.value.toLowerCase();
  const filtered = recipes.filter(recipe =>
    recipe.name.toLowerCase().includes(query) ||
    recipe.ingredients.toLowerCase().includes(query)
  );
  displayRecipes(filtered);
});

displayRecipes(recipes);


